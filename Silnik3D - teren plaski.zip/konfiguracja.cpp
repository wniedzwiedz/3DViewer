/*

 C++ przez OpenGL - szablon do �wicze� laboratoryjnych
 (C) Micha� Turek.

*/

#ifdef _KONFIGURACJA


	/******************* SZABLON **************************/







	// KONFIGURACJA	

	
	ustalObszar (150);						// promien obszaru (kola), po jakim kamera mo�e sie porusza�

//	rejestrujPrzeszkode(-25,-25,-35,-35);	// Funkcja rejestruj�ca przeszkody - kolejne parametry to X1, Z1, X2, Z2 prostok�ta, kt�ry jest dodatkowo zabroniony dla kamery
											// Funkcj� mo�na wywo�ywac wielokrotnie dla r�nych obszar�w

	
	rejestrujPrzeszkode(-30,-40,-10,-20);
	rejestrujPrzeszkode(-30,0,-10,20);


	/******************************************************/


#undef _KONFIGURACJA
#endif
