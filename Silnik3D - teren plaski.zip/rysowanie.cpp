/*

 C++ przez OpenGL - szablon do �wicze� laboratoryjnych
 (C) Micha� Turek.

*/

#ifdef _RYSOWANIE


	/******************* SZABLON **************************/



	
	// Tekstura podloza jest zapisana w pliku "data/land.bmp", definiowana bezpo�rednio w 3ds. 
	// Wymagany format pliku: bmp, 24 bity na pixel.

	glPushMatrix();
		glTranslatef(0,1,0);
		rysujModel("teren"); // malowanie pod�o�a
		rysujModel("niebo"); // malowanie nieba
	glPopMatrix();
		

	
	/*
	if (kierunek) samZ +=0.2;
		else samZ -=0.2;

	if (samZ > 75) kierunek = false;
	if (samZ < 0) kierunek = true;
	*/

	samZ += predkosc;

	if (samZ > 50) predkosc -= 0.003;
	if (samZ < 0) predkosc += 0.003;

	glPushMatrix();
	glTranslatef(49,-5,samZ ); 
	rysujModel("sam.3ds");
	glPopMatrix();

	
	
	
	
	
	
	
	// RYSOWANIE DROGI

	glPushMatrix();

	glTranslatef(50,-5,0); // przesuniecie na podloze
	rysujModel("droga_prosta.3ds");
	glTranslatef(0,0,24);
	rysujModel("droga_prosta.3ds");
	glTranslatef(0,0,8);
	rysujModel("droga_przejscie.3ds");	
	glTranslatef(0,0,7);
	glPushMatrix();
		rysujModel("droga_skrzyzowanie.3ds");
		glTranslatef(0,0,15);
		rysujModel("droga_przejscie.3ds");
		glTranslatef(0,0,24);
		rysujModel("droga_prosta.3ds");
		glTranslatef(0,0,3);
		glRotatef(90,0,1,0);
		rysujModel("droga_koniec.3ds");
	glPopMatrix();
	glRotatef(90,0,1,0);
	glTranslatef(0,0,-7);
	rysujModel("droga_prosta.3ds");
	glTranslatef(0,0,-24);

	glPopMatrix();


	glPushMatrix();
		glTranslatef(0,-5,0); // przesuniecie na podloze
		glTranslatef(0,0,-100);
		glRotatef(-90,0,1,0);
		rysujModel("droga_koniec.3ds");
		glRotatef(90,0,1,0);
		
		glTranslatef(0,0,24);
		rysujModel("droga_prosta.3ds");
		glTranslatef(0,0,24);
		rysujModel("droga_prosta.3ds");
		glTranslatef(0,0,24);
		rysujModel("droga_prosta.3ds");
		glTranslatef(0,0,8);
		rysujModel("droga_przejscie.3ds");
		glTranslatef(0,0,7);
		glPushMatrix();
			rysujModel("droga_skrzyzowanie.3ds");
			glTranslatef(0,0,15);
			rysujModel("droga_przejscie.3ds");
			glTranslatef(0,0,24);
			rysujModel("droga_prosta.3ds");
			glTranslatef(0,0,24);
			rysujModel("droga_prosta.3ds");
			glTranslatef(0,0,24);
			rysujModel("droga_prosta.3ds");
			glTranslatef(0,0,24);
			rysujModel("droga_prosta.3ds");
			glTranslatef(0,0,3);
			glRotatef(90,0,1,0);
			rysujModel("droga_koniec.3ds");
		glPopMatrix();
		glRotatef(90,0,1,0);
		glTranslatef(0,0,-7);
		rysujModel("droga_prosta.3ds");
		glTranslatef(0,0,-24);
		rysujModel("droga_prosta.3ds");
		glTranslatef(0,0,-31);
		glPushMatrix();
			rysujModel("droga_skrzyzowanie.3ds");
			glRotatef(90,0,1,0);
			glTranslatef(0,0,-7);
			rysujModel("droga_przejscie.3ds");
			rysujModel("sam.3ds");
			glTranslatef(0,0,-8);
			rysujModel("droga_prosta.3ds");
			glTranslatef(0,0,-24);
			rysujModel("droga_prosta.3ds");
			glTranslatef(0,0,-31);
			glRotatef(-90,0,1,0);
			rysujModel("droga_zakret.3ds");
			glRotatef(180,0,1,0);
			glTranslatef(0,0,-7);
			rysujModel("droga_prosta.3ds");
			glTranslatef(0,0,-7);
			rysujModel("droga_prosta.3ds");
			glTranslatef(0,0,-27);
			glRotatef(-90,0,1,0);
			rysujModel("droga_koniec.3ds");	
		glPopMatrix();
		glTranslatef(0,0,-14);
		rysujModel("droga_zakret.3ds");
		glRotatef(-90,0,1,0);
		glTranslatef(0,0,-7);
		rysujModel("droga_prosta.3ds");
		glTranslatef(0,0,-27);
		glRotatef(-90,0,1,0);
		rysujModel("droga_koniec.3ds");	
	glPopMatrix();


	// RYSOWANIE TOR�W
	
	int a = 0;
	glPushMatrix();
		glTranslatef(15,-5,-100); // przesuniecie na podloze
		// rysowanie cystern
			tankerPos+=tankerSpeed;
			if (tankerPos >=117) tankerSpeed*=0.98;
			glPushMatrix();
			glTranslatef(0,0,10+tankerPos); 
			rysujModel("cysterna");
			glTranslatef(0,0,20); 
			rysujModel("cysterna");
			glTranslatef(0,0,20); 
			rysujModel("cysterna");
			glTranslatef(0,0,-60); 
			glPopMatrix();
		for (a = 0; a < 15; a++)
		{
			rysujModel("tor.3ds");
			if (a == 7) glPushMatrix();
			glTranslatef(0,0,13.7); // przesuniecie na podloze
		}
		glPopMatrix();
		glRotatef(180,0,1,0);
		for (a = 0; a < 4; a++)
		{
			rysujModel("tor_zakret.3ds");
			glTranslatef(-(5.18+3.04)/2,0,(14.64 + 13.27)/2); // przesuniecie na podloze
			glRotatef(-33,0,1,0);
		}
		glTranslatef(0,0,13.7); // przesuniecie na podloze
		for (a = 0; a < 10; a++)
		{
			rysujModel("tor.3ds");
			glTranslatef(0,0,13.7); // przesuniecie na podloze
		}
	glPopMatrix();

	
	// RYSOWANIE LINII ELEKTRYCZNEJ

	glPushMatrix();
		glTranslatef(10,-6,-100); // przesuniecie na podloze
		rysujModel("linia_slup.3ds");
		
//		int b;
//		int c;
		
		for (a = 0; a < 5; a++)
			{
				glTranslatef(0,0,8.12); // przesuniecie na podloze
				rysujModel("linia.3ds");
			}
		
		
		
		glPopMatrix();



	// INNE OBIEKTY
	

	glPushMatrix();
		glTranslatef(-20,0,-30);
		rysujModel("zbiornik1.3ds");	
		glTranslatef(0,0,40);
		rysujModel("zbiornik2.3ds");	
	
		glTranslatef(50,0,0);
		rysujModel("zbiornik3.3ds");	
	glPopMatrix();

	glEnable (GL_COLOR_MATERIAL);
	glDisable (GL_TEXTURE_2D);
	glColor3f(1.0,0,0.0);
	// rysowanie bez atrybut�w materialu i tekstury
	// ...
	
	glEnable (GL_TEXTURE_2D);
	glDisable (GL_COLOR_MATERIAL);

/*
	car1X += car1XSpeed;
	car1Z += car1ZSpeed;
	glPushMatrix();
		glTranslatef(-2,-5.0,0); // vector
		if (car1Z < -20) car1ZSpeed +=0.001;
		if (car1Z > 20) car1ZSpeed -=0.001;
		glTranslatef(car1X,0,car1Z);
		rysujModel("sam.3ds");	
	glPopMatrix();
*/	






	/******************************************************/


#undef _RYSOWANIE
#endif
